"""An ipykernel mock"""

__version__ = "6.9.2"
__all__ = ["Comm", "CommManager", "__version__"]

import re
from typing import List

from .comm import Comm, CommManager

# Build up version_info tuple for backwards compatibility
pattern = r"(?P<major>\d+).(?P<minor>\d+).(?P<patch>\d+)(?P<rest>.*)"
match = re.match(pattern, __version__)
assert match is not None
parts: List[object] = [int(match[part]) for part in ["major", "minor", "patch"]]
if match["rest"]:
    parts.append(match["rest"])
version_info = tuple(parts)
