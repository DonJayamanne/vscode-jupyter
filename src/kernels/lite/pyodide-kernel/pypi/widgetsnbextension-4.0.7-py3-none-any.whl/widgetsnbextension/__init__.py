"""A widgetsnbextension mock"""

__version__ = "4.0.7"
